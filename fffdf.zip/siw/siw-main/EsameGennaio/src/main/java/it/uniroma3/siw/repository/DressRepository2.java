package siw;

public interface DressRepository implements CrudRepository<Dress,Long>{

}
