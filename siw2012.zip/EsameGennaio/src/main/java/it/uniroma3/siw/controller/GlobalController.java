package it.uniroma3.siw.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.controller.validator.CredentialsValidator;
import it.uniroma3.siw.controller.validator.ReviewValidator;
import it.uniroma3.siw.controller.validator.UserValidator;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Dress;
import it.uniroma3.siw.model.Review;
import it.uniroma3.siw.model.Stylist;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.DressRepository;
import it.uniroma3.siw.repository.ReviewRepository;
import it.uniroma3.siw.repository.StylistRepository;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.DressService;
import it.uniroma3.siw.service.UserService;

@Controller
public class GlobalController {
	@Autowired
	private CredentialsService credentialsService;

	@Autowired
	private DressRepository dressRepository;

	@Autowired
	private StylistRepository stylistRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private ReviewRepository reviewRepository;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	private CredentialsValidator credentialsValidator;

	@Autowired
	private DressService dressService;

	@Autowired
	private ReviewValidator reviewValidator;



	@GetMapping("/")
	public String index(Model model) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = null;
		Credentials credentials = null;
		if(!(authentication instanceof AnonymousAuthenticationToken)){
			userDetails = (UserDetails)authentication.getPrincipal();
			credentials = this.credentialsService.getCredentials(userDetails.getUsername());
		}
		if(credentials != null && credentials.getRole().equals(Credentials.ADMIN_ROLE)) return "admin/indexAdmin.html";

		/*model.addAttribute("userDetails", userDetails);*/
		model.addAttribute("dresses", this.dressRepository.findAll());
		return "index.html";
	}
	@GetMapping("/index")
	public String index2(Model model){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = null;
		Credentials credentials = null;
		if(!(authentication instanceof AnonymousAuthenticationToken)){
			userDetails = (UserDetails)authentication.getPrincipal();
			credentials = credentialsService.getCredentials(userDetails.getUsername());
		}
		if(credentials != null && credentials.getRole().equals(Credentials.ADMIN_ROLE)) return "admin/indexAdmin.html";

		model.addAttribute("userDetails", userDetails);
		model.addAttribute("dresses", this.dressRepository.findAll());
		return "index.html";
	}

	@GetMapping(value = "/login")
	public String showLoginForm (Model model) {
		return "formLogin.html";
	}

	@GetMapping(value = "/register")
	public String showRegisterForm (Model model) {
		model.addAttribute("user", new User());
		model.addAttribute("credentials", new Credentials());
		return "formRegister.html";
	}
	
	@GetMapping("/dresses")
	public String dresses(Model model){

		model.addAttribute("dresses", this.dressRepository.findAll());
		return "dresses.html";
	}

	@GetMapping("/stylists")
	public String stylists(Model model){

		model.addAttribute("stylists", this.stylistRepository.findAll());
		return "stylists.html";
	}

	@PostMapping("/register")
	public String registerUser(@Valid @ModelAttribute("user") User user,
			BindingResult userBindingResult, @Valid
			@ModelAttribute("credentials") Credentials credentials,
			BindingResult credentialsBindingResult,
			Model model) {
		this.userValidator.validate(user,userBindingResult);
		this.credentialsValidator.validate(credentials, credentialsBindingResult);                        
		if(!userBindingResult.hasErrors() && ! credentialsBindingResult.hasErrors()) {
			credentials.setUser(user);
			credentialsService.saveCredentials(credentials);
			userService.saveUser(user);
			model.addAttribute("user", user);
			return "formLogin.html";
		}
		return "formRegister.html";
	}

	@GetMapping("/stylist/{id}")
	public String stylist(@PathVariable("id") Long id, Model model){

		model.addAttribute("userDetails", this.userService.getUserDetails());

		Stylist stylist = this.stylistRepository.findById(id).get();
		model.addAttribute("stylist", stylist);

		return "stylist.html";
	}

	@GetMapping("/dress/{id}")
	public String dress(@PathVariable("id") Long id, Model model) {

		UserDetails userDetails = this.userService.getUserDetails();
		model.addAttribute("userDetails", userDetails);

		Dress dress = this.dressRepository.findById(id).get();

		model.addAttribute("dress", dress);

		/* Gestione della review */
		if (userDetails != null){
			if(this.credentialsService.getCredentials(userDetails.getUsername()) !=null){
				model.addAttribute("review", new Review());
			}
		}

		if(userDetails != null && this.credentialsService.getCredentials(userDetails.getUsername()).getRole().equals(Credentials.ADMIN_ROLE)){
			model.addAttribute("admin", true);
		}
		return "dress.html";
	}

	@PostMapping("/user/review/{dressId}")
	public String addReview(Model model, @Valid @ModelAttribute("review") Review review, BindingResult bindingResult, @PathVariable("dressId") Long id){
		this.reviewValidator.validate(review,bindingResult);
		Dress dress= this.dressRepository.findById(id).get();
		String username = this.userService.getUserDetails().getUsername();

		if(!bindingResult.hasErrors() && !this.dressService.hasReviewFromAuthor(id, username)){
			if(this.userService.getUserDetails() != null && !dress.getReviews().contains(review)){
				review.setAuthor(username);
				this.reviewRepository.save(review);
				dress.getReviews().add(review);
			}
		}
		this.dressRepository.save(dress);

		if(this.userService.getUserDetails() != null && !dress.getReviews().contains(review)){
			if(!this.dressService.hasReviewFromAuthor(id, username)){
				this.reviewRepository.save(review);
				dress.getReviews().add(review);
			}
			else{
				model.addAttribute("reviewError", "Already Reviewed!");
			}

		}
		this.dressRepository.save(dress);

		model.addAttribute("dress", dress);

		if(this.credentialsService.getCredentials(username).getRole().equals(Credentials.ADMIN_ROLE)){
			model.addAttribute("admin", true);
		}
		return "dress.html";
	}

	@GetMapping("/admin/deleteReview/{dressId}/{reviewId}")
	public String removeReview(Model model, @PathVariable("dressId") Long dressId,@PathVariable("reviewId") Long reviewId){
		Dress dress = this.dressRepository.findById(dressId).get();
		Review review = this.reviewRepository.findById(reviewId).get();
		UserDetails userDetails = this.userService.getUserDetails();

		dress.getReviews().remove(review);
		this.reviewRepository.delete(review);
		this.dressRepository.save(dress);

		model.addAttribute("dress", dress);

		if (userDetails != null){
			if(this.credentialsService.getCredentials(userDetails.getUsername()) !=null ){
				model.addAttribute("review", new Review());
			}
			if(this.dressService.hasReviewFromAuthor(dressId, userDetails.getUsername())){
				model.addAttribute("reviewError", "You have already reviewed this dress.");
			}

		}
		return "dress.html";
	}
}