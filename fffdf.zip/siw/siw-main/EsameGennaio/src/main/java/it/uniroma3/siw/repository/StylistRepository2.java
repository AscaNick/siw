package siw;

public interface Stylist implements CrudRepository<Stylist,Long>{

}
