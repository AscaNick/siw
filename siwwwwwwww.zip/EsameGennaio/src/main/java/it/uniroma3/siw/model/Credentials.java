package it.uniroma3.siw.model;

public class Credentials {

}
