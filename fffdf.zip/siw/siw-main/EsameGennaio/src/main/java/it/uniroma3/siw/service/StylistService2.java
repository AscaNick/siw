package siw;

public class StylistService {

}
