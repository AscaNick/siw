package siw;

public interface ReviewRepository implements CrudRepository<Review,Long>{

}
