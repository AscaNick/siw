package it.uniroma3.siw.service;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Dress;
import it.uniroma3.siw.model.Review;
import it.uniroma3.siw.model.Stylist;
import it.uniroma3.siw.repository.DressRepository;
import it.uniroma3.siw.repository.StylistRepository;
import jakarta.transaction.Transactional;

@Service
public class DressService {

    @Autowired
    StylistRepository stylistRepository;

    @Autowired
    DressRepository dressRepository;

    @Transactional
    public void createDress(Dress dress){

    	this.dressRepository.save(dress);
    }
    
    //cambia i dettagli del prodotto,come prezzo, nome
    @Transactional
    public void editDetailsToDress(Dress dress) {
        // Recupera il prodotto esistente dal repository utilizzando l'ID
        Dress existingDress = dressRepository.findById(dress.getId()).orElse(null);

        if (existingDress != null) {
            // Aggiorna i dettagli del prodotto con i nuovi valori
            existingDress.setNome(dress.getNome());
            existingDress.setPrezzo(dress.getPrezzo());
            existingDress.setDescrizione(dress.getDescrizione());

            // Salva le modifiche nel repository
            dressRepository.save(dress);
        }
    }
    
    @Transactional
    public void setStylistToDress(Dress dress, Long dressId) {
        Stylist stylist = this.stylistRepository.findById(dressId).get();

        stylist.getDresses().add(dress);
        dress.getStylists().add(stylist);

        this.stylistRepository.save(stylist);
        this.dressRepository.save(dress);
    }

    @Transactional
    public void removeStylistToDress(Dress dress, Long dressId) {
        Stylist stylist = this.stylistRepository.findById(dressId).get();

        stylist.getDresses().remove(dress);
        dress.getStylists().remove(stylist);

        this.stylistRepository.save(stylist);
        this.dressRepository.save(dress);
    }

    public boolean hasReviewFromAuthor(Long dressId, String username){
        Dress dress = this.dressRepository.findById(dressId).get();
        Set<Review> reviews = dress.getReviews();
        for (Review review: reviews) {
            if(review.getAuthor().equals(username)) {
                return true;
            }
        }
        return false;
    }
}