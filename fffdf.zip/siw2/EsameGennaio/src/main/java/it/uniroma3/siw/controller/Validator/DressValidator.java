package siw2;

public class DressValidator implements Validator {
	  @Autowired
	  private DressRepository dressRepository;

	  @Override
	  public void validate(Object o, Errors errors) {
	    Dress dress = (Dress)o;
	    if (dress.getNome()!=null && movie.getPrezzo()!=null  
			&& dressRepository.existsByNomeAndPrezzo(dress.getNome(), dress.getPrezzo())) {
	      errors.reject("dress.duplicate");
	    }
	  }
	  
	  @Override
	    public boolean supports(Class<?> aClass) {
	      return Dress.class.equals(aClass);
	    }
	{

}
